import greenfoot.*;

public class ImagemFundo extends Actor {
    
    public ImagemFundo(String imagem) {
        setImage(imagem);
    }
}
