
public enum EstadoInimigo  
{
    PARADO_ESQ,
    PARADO_DIR,
    ATACANDO_ESQ,
    ATACANDO_DIR
}
