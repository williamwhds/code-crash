public enum EstadoJogador {
    PARADO_DIR,
    PARADO_ESQ,
    ANDANDO_DIR,
    ANDANDO_ESQ,
    PULANDO,
    ATIRANDO_DIR,
    ATIRANDO_ESQ,
    DANO,
}