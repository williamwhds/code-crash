import greenfoot.*;

public enum EstadoChefe  
{
    PARADO_DIR,
    PARADO_ESQ,
    ATACANDO_DIR,
    ATACANDO_ESQ,
}
