package com.example.game

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import kotlin.random.Random


class MainActivity : AppCompatActivity() {
    private lateinit var topeira: ImageView
    private val handler = Handler(Looper.getMainLooper())
    private var acertos = 0
    private var DelayEntreAcertos: Long = 1500
    private var record = "0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        topeira = findViewById(R.id.imagemTopeira)
        val pontuacao: TextView = findViewById(R.id.textView_numeroAcertos)
        val maior_pontuacao: TextView = findViewById(R.id.textView_Recorde)
        val reset_btn: Button = findViewById(R.id.button_Reset)
        val chao: ConstraintLayout = findViewById(R.id.ConstraintChao)
        val mensagem: TextView = findViewById(R.id.Mensagem)

        var perdeu: Boolean = false

        topeira.setOnClickListener {
            acertos++
            topeira.visibility = ImageView.GONE
            pontuacao.text = "$acertos"
            DelayEntreAcertos-=50

            if (pontuacao.text.toString().toLong() >= maior_pontuacao.text.toString().toLong()) {
                maior_pontuacao.text = pontuacao.text.toString()
                record = maior_pontuacao.text.toString()
            }
        }

        reset_btn.setOnClickListener {
            pontuacao.text = "0"
            acertos=0;
            DelayEntreAcertos = 1500
            mensagem.text = ""
            topeira.visibility = ImageView.VISIBLE
            perdeu = false
        }

        chao.setOnClickListener{
            topeira.visibility = ImageView.GONE
            mensagem.text = "VOCÊ PERDEU!"
            perdeu = true
        }

        val moverTopera = object : Runnable {
            override fun run() {
                val maxX = resources.displayMetrics.widthPixels - topeira.width
                val maxY = resources.displayMetrics.heightPixels - topeira.height

                val randomX = Random.nextInt(maxX)
                val randomY = Random.nextInt(maxY)
                if (randomX + topeira.width <= maxX && randomY + topeira.height <= maxY) {
                    topeira.x = randomX.toFloat()
                    topeira.y = randomY.toFloat()
                }
                handler.postDelayed(this, DelayEntreAcertos)
                if (!perdeu) topeira.visibility = ImageView.VISIBLE
            }
        }
        handler.post(moverTopera)
    }
}

